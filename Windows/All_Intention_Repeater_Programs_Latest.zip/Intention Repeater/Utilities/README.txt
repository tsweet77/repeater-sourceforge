Utilities
by Anthro Teacher (AnthroHeart) aka Thomas Sweet
Website: http://www.intentionrepeater.com
Email: healing@intentionrepeater.com
Forum: https://intentionrepeater.boards.net/
GitHub: https://github.com/tsweet77

Program and Sourcecode Source: https://intention-repeater.sourceforge.io/

Intention Color converts an intention into a color.

Sigil Generator creates a sigil from an intention.